import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const FetalGrowthChart = () => {
    const [growthData, setGrowthData] = useState([]);

    useEffect(() => {
        const fetchGrowthData = async () => {
            const token = localStorage.getItem("userToken"); // Lấy token ngay lúc gọi API
            console.log("Token lấy từ localStorage:", token);
            if (!token) {
                console.error("Không tìm thấy token trong localStorage!");
                return;
            }

            try {
                const response = await fetch("http://localhost:5001/api/fetalgrowth/motherId", {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`,
                        "Content-Type": "application/json",
                    },
                });

                if (!response.ok) {
                    throw new Error(`Failed to fetch data: ${response.status}`);
                }

                const data = await response.json();
                setGrowthData(data.sort((a, b) => a.gestationalAge - b.gestationalAge));
            } catch (error) {
                console.error("Error fetching fetal growth data:", error);
            }
        };

        fetchGrowthData();
    }, []); // Không cần thêm `token` vào dependency nữa

    return (
        <ResponsiveContainer width="100%" height={400}>
            <LineChart data={growthData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="gestationalAge" label={{ value: "Tuần thai", position: "insideBottom", offset: -5 }} />
                <YAxis label={{ value: "Cân nặng (g)", angle: -90, position: "insideLeft" }} />
                <Tooltip />
                <Line type="monotone" dataKey="weight" stroke="#8884d8" strokeWidth={2} />
            </LineChart>
        </ResponsiveContainer>
    );
};

export default FetalGrowthChart;
